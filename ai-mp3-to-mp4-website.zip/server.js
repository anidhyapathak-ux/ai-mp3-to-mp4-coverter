import express from "express";
import multer from "multer";
import OpenAI from "openai";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const exec = promisify(execFile);
const app = express();
const upload = multer({ dest: "uploads/" });
const port = process.env.PORT || 3000;

app.use(express.static("public"));
app.use(express.json());

app.post("/api/convert", upload.fields([
  { name: "audio", maxCount: 1 },
  { name: "image", maxCount: 1 }
]), async (req, res) => {
  const audio = req.files?.audio?.[0];
  const image = req.files?.image?.[0];
  if (!audio) return res.status(400).json({ error: "Please upload an MP3 file." });

  const id = crypto.randomUUID();
  const out = path.join("uploads", `${id}.mp4`);
  const bg = image?.path;

  try {
    // Static image + audio → MP4. FFmpeg must be installed on the server.
    const inputImage = bg || "public/default-bg.jpg";
    await exec("ffmpeg", [
      "-y", "-loop", "1", "-i", inputImage, "-i", audio.path,
      "-c:v", "libx264", "-tune", "stillimage", "-c:a", "aac",
      "-b:a", "192k", "-pix_fmt", "yuv420p", "-shortest", out
    ]);
    res.download(out, "converted.mp4", async () => {
      await Promise.allSettled([
        fs.rm(audio.path, { force: true }),
        bg ? fs.rm(bg, { force: true }) : Promise.resolve(),
        fs.rm(out, { force: true })
      ]);
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Conversion failed. Make sure FFmpeg is installed." });
  }
});

app.post("/api/transcribe", upload.single("audio"), async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "OPENAI_API_KEY is not configured." });
  if (!req.file) return res.status(400).json({ error: "Please upload an audio file." });

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await client.audio.transcriptions.create({
      file: requireFile(req.file.path),
      model: "gpt-4o-mini-transcribe"
    });
    await fs.rm(req.file.path, { force: true });
    res.json({ text: result.text });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Transcription failed." });
  }
});

function requireFile(p) {
  // OpenAI's Node SDK accepts a File-like object from fs.createReadStream.
  return fsSync.createReadStream(p);
}

app.listen(port, () => console.log(`AI MP3→MP4 running on http://localhost:${port}`));
