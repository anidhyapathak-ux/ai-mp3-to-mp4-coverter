const audio=document.querySelector("#audio"), image=document.querySelector("#image");
const name=document.querySelector("#audioName"), status=document.querySelector("#status");
const download=document.querySelector("#download"), text=document.querySelector("#text");
audio.onchange=()=>name.textContent=audio.files[0]?.name||"No audio selected";

document.querySelector("#convert").onclick=async()=>{
  if(!audio.files[0]) return status.textContent="Choose an MP3 first.";
  status.textContent="Converting…";
  const fd=new FormData(); fd.append("audio",audio.files[0]); if(image.files[0]) fd.append("image",image.files[0]);
  try{
    const r=await fetch("/api/convert",{method:"POST",body:fd});
    if(!r.ok) throw new Error((await r.json()).error||"Conversion failed");
    const blob=await r.blob(); const url=URL.createObjectURL(blob);
    download.href=url; download.download="converted.mp4"; download.hidden=false;
    status.textContent="Done! Your MP4 is ready.";
  }catch(e){status.textContent=e.message}
};

document.querySelector("#transcribe").onclick=async()=>{
  if(!audio.files[0]) return status.textContent="Choose an MP3 first.";
  status.textContent="Transcribing with AI…";
  const fd=new FormData(); fd.append("audio",audio.files[0]);
  try{
    const r=await fetch("/api/transcribe",{method:"POST",body:fd});
    const data=await r.json(); if(!r.ok) throw new Error(data.error||"Transcription failed");
    text.value=data.text; status.textContent="Transcript ready.";
  }catch(e){status.textContent=e.message}
};